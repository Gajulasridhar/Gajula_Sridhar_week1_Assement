﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Gajula_sridhar_Week_2_Assesment
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public double Price { get; set; }
    }

    public interface IBookRepository
    {
        void CreateBook(Book book);
        void UpdateBook(int bookId, string propertyName, string newValue);
        Book GetBookById(int bookId);
        List<Book> GetBooksByName(string bookName);
        List<Book> GetBooksByAuthor(string author);
        List<Book> GetBooksByAuthorAndPublisher(string author, string publisher);
        List<Book> GetAllBooks();
    }

    public class BookRepository : IBookRepository
    {
        private List<Book> books = new List<Book>();

        public void CreateBook(Book book)
        {
            try
            {
                books.Add(book);
            }
            catch (Exception ex)
            {
                Console.WriteLine( ex.Message);
            }
        }

        public void UpdateBook(int bookId, string propertyName, string newValue)
        {
            try
            {
                Book book = new Book();
               
                    switch (propertyName.ToLower())
                    {
                        case "bookname":
                            book.BookName = newValue;
                            break;
                        case "price":
                               double newPrice=Double.Parse(newValue);
                                book.Price = newPrice;
                            
                           
                            break;
                        case "author":
                            book.Author = newValue;
                            break;
                        case "publisher":
                            book.Publisher = newValue;
                            break;
                        default:
                              Console.WriteLine("Invalid propertyName");
                        break;
                    }
                
                
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error:{ex.Message}");
            }
        }

        public Book GetBookById(int bookId)
        {
            
        }

        public List<Book> GetBooksByName(string bookName)
        {
           
        }

        public List<Book> GetBooksByAuthor(string author)
        {
            
        }

        public List<Book> GetBooksByAuthorAndPublisher(string author, string publisher)
        {
           
        }

        public List<Book> GetAllBooks()
        {
            return books;
        }
    }

    public class Program
    {
        static void Main()
        {
            IBookRepository repository = new BookRepository();

            while (true)
            {
                Console.WriteLine("MENU:");
                Console.WriteLine("1. Create Book");
                Console.WriteLine("2. Update Book Details");
                Console.WriteLine("3. Display Book Details");
                Console.WriteLine("4. Exit");
                int option = int.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        CreateBook(repository);
                        break;
                    case 2:
                        UpdateBookDetails(repository);
                        break;
                    case 3:
                        DisplayBookDetails(repository);
                        break;
                    case 4:
                        return;
                    default:
                        Console.WriteLine("Invalid option");
                        break;
                }
            }
        }

        private static void CreateBook(IBookRepository repository)
        {
            try
            {
                Console.Write("Enter Book ID: ");
                int bookId = int.Parse(Console.ReadLine());
                Console.Write("Enter Book Name: ");
                string bookName = Console.ReadLine();
                Console.Write("Enter Price: ");
                double price = double.Parse(Console.ReadLine());
                Console.Write("Enter Author: ");
                string author = Console.ReadLine();
                Console.Write("Enter Publisher: ");
                string publisher = Console.ReadLine();

                Book newBook = new Book
                {
                    BookId = bookId,
                    BookName = bookName,
                    Price = price,
                    Author = author,
                    Publisher = publisher
                };

                repository.CreateBook(newBook);
                Console.WriteLine("Book created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private static void UpdateBookDetails(IBookRepository repository)
        {
            try
            {
                Console.Write("Enter Book ID to update: ");
                int bookId = int.Parse(Console.ReadLine());
                Console.Write("Enter property name to update (bookname, price, author, publisher): ");
                string propertyName = Console.ReadLine();
                Console.Write($"Enter new value for {propertyName}: ");
                var newValue = Console.ReadLine();

                repository.UpdateBook(bookId, propertyName, newValue);
                Console.WriteLine("Book updated successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private static void DisplayBookDetails(IBookRepository repository)
        {
            try
            {
                Console.WriteLine("Display options:");
                Console.WriteLine("a. Display book details based on Book ID");
                Console.WriteLine("b. Display book details based on Book Name");
                Console.WriteLine("c. Display all books based on Author");
                Console.WriteLine("d. Display all books based on Author and Publisher");
                Console.WriteLine("e. Display all books");
                char Option = char.Parse(Console.ReadLine());
                
                switch (Option)
                {
                    case 'a':
                        Console.Write("Enter Book ID: ");
                        int bookId = int.Parse(Console.ReadLine());
                        Book bookById = repository.GetBookById(bookId);
                       
                            DisplayBook(bookById);
                        
                        break;
                    case 'b':
                        Console.Write("Enter Book Name: ");
                        string bookName = Console.ReadLine();
                        List<Book> booksByName = repository.GetBooksByName(bookName);
                        
                            booksByName.ForEach(DisplayBook);
                        
                  
                        break;
                    case 'c':
                        Console.Write("Enter Author: ");
                        string author = Console.ReadLine();
                        List<Book> booksByAuthor = repository.GetBooksByAuthor(author);
                       
                       
                        break;
                    case 'd':
                        Console.Write("Enter Author: ");
                        author = Console.ReadLine();
                        Console.Write("Enter Publisher: ");
                        string publisher = Console.ReadLine();
                        List<Book> booksByAuthorAndPublisher = repository.GetBooksByAuthorAndPublisher(author, publisher);
                       
                            booksByAuthorAndPublisher.ForEach(DisplayBook);
                        
                       
                        break;
                    case 'e':
                        List<Book> allBooks = repository.GetAllBooks();
                        
                            allBooks.ForEach(DisplayBook);
                        
                       
                        break;
                    default:
                        Console.WriteLine("Invalid option");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        public static void DisplayBook(Book book)
        {
            Console.WriteLine($"Book ID: {book.BookId}");
            Console.WriteLine($"Book Name: {book.BookName}");
            Console.WriteLine($"Author: {book.Author}");
            Console.WriteLine($"Publisher: {book.Publisher}");
            Console.WriteLine($"Price: {book.Price}");
          
        }
    }
}
